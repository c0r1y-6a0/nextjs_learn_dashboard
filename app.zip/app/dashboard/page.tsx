export default function Page() {
  return <p>Dashboard Page</p>;
}
